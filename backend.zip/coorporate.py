import csv
import time

import psycopg2
csv.field_size_limit(1000000500)

count = 0
records = []

try:

    postgres_insert_query = """ INSERT INTO coreapp_peoplelist 
    (
    fullname,
    address1,
    phone,
    cnic,
    issuedate, 
    vender) VALUES (%s,%s,%s,%s,%s,%s)"""

    with open('/home/data/CORPORATE.txt', 'r',encoding="utf8", errors='ignore') as csvFile:
        reader = csv.reader(csvFile, delimiter='\t')
        line_count = 0
        for row in reader:
            try:
                if line_count == 0:
                    print(f'Column names are {", ".join(row)}')
                    line_count += 1
                else:
                    # print(f'\t{row[0]} is with name {row[1]} cnic {row[2]}  address {row[4]} city {row[6]} date {row[9]}.')
                    line_count += 1
                    record = (row[2][:500], row[4][:4500], int(row[0]), row[5][:500], row[13][:500], 'Ufone Corporate Data')
#                    print(record)
 #                   break
                    if line_count >  290003:
                        records.append(record)
                    if len(records)>=10000:
                        try:
                            connection = psycopg2.connect(user="blackgeeks",
                                                          password="team@blackgeeks",
                                                          host="207.180.237.86",
                                                          port="5432",
                                                          database="people")
                            cursor = connection.cursor()

                            cursor.executemany(postgres_insert_query, records)
                            connection.commit()
                            print(line_count, "Record inserted successfully into mobile table")
                            records = []
                            cursor.close()
                            connection.close()
                        except:
                            connection.rollback()
                            pass

                # print(line_count)
            except Exception as e:
                print('Exception', str(e))
                print(f'Column names are {", ".join(row)}')

                print(line_count)
        connection = psycopg2.connect(user="blackgeeks",
                                      password="team@blackgeeks",
                                      host="207.180.237.86",
                                      port="5432",
                                      database="people")
        cursor = connection.cursor()
        cursor.executemany(postgres_insert_query, records)
        connection.commit()
        cursor.close()
        connection.close()
        print(line_count, "Record inserted successfully into mobile table")

except (Exception, psycopg2.Error) as error:
    print("Failed to insert record into mobile table", error)

csvFile.close()
