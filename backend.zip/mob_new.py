import csv
import time

import psycopg2
csv.field_size_limit(100000000)

count = 0
records = []

try:
    connection = psycopg2.connect(user="blackgeeks",
                                  password="team@blackgeeks",
                                  host="207.180.237.86",
                                  port="5432",
                                  database="people")
    cursor = connection.cursor()
    postgres_insert_query = """ INSERT INTO coreapp_peoplelist 
    (
    fullname,
    address1,
    address2,
    phone,
    cnic,
    status,
    issuedate, 
    vender) VALUES (%s,%s,%s,%s,%s,%s,%s,%s)"""

    with open('/home/data/Prepaid_Feb19.csv', 'r',encoding="utf8", errors='ignore') as csvFile:

        reader = csv.reader(csvFile, delimiter='|')
        line_count = 0
        for row in reader:
            try:
                if line_count == 0:
                    print(f'Column names are {", ".join(row)}')
                    line_count += 1
                else:
                    # print(f'\t{row[0]} is with name {row[1]} cnic {row[2]}  address {row[4]} city {row[6]} date {row[9]}.')
                    line_count += 1
                    record = (str(row[1])[:500], row[4][:3500], row[6][:500], int(row[0]), row[2][:500], row[7][:500], row[9][:500],'Mobilink Post paid (new data)')
#                    print(record)
                    records.append(record)

                # print(line_count)
            except Exception as e:
                print('Exception', str(e))
        cursor.executemany(postgres_insert_query, records)
        connection.commit()
        count = cursor.rowcount
        print(line_count, "Record inserted successfully into mobile table")

except (Exception, psycopg2.Error) as error:
    print("Failed to insert record into mobile table", error)

csvFile.close()
print(count)
