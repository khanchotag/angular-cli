import csv
import time

import psycopg2
csv.field_size_limit(1000000050)

count = 0
records = []

try:
    postgres_insert_query = """ INSERT INTO coreapp_peoplelist 
    (
    fullname,
    address1,
    phone,
    cnic,
    status,
    vender) VALUES (%s,%s,%s,%s,%s,%s)"""

    with open('/home/data/NIC.txt', 'r',encoding="utf8", errors='ignore') as csvFile:
        reader = csv.reader(csvFile, delimiter='\t')
        line_count = 0
        for row in reader:
            try:
                if line_count == 0:
                    print(f'Column names are {", ".join(row)}')
                    line_count += 1
                else:
                    line_count += 1
                    record = (row[2][:500], row[4][:4500],int(row[0][:500]),row[5][:500],row[9][:500],'PTA Ufone(new data)')
#                    print(record)
                    records.append(record)
 #                   break
                    if len(records)>=10000:
                        connection = psycopg2.connect(user="blackgeeks",
                                                      password="team@blackgeeks",
                                                      host="207.180.237.86",
                                                      port="5432",
                                                      database="people")
                        cursor = connection.cursor()

                        cursor.executemany(postgres_insert_query, records)
                        connection.commit()
                        count = cursor.rowcount
                        cursor.close()
                        connection.close()
                        print(line_count, "Record inserted successfully into mobile table")
                        records = []
            except Exception as e:
                print('Exception', str(e))
        connection = psycopg2.connect(user="blackgeeks",
                                      password="team@blackgeeks",
                                      host="207.180.237.86",
                                      port="5432",
                                      database="people")
        cursor = connection.cursor()

        cursor.executemany(postgres_insert_query, records)
        connection.commit()
        count = cursor.rowcount
        print(line_count, "Record inserted successfully into mobile table")
        cursor.close()
        connection.close()

except (Exception, psycopg2.Error) as error:
    print("Failed to insert record into mobile table", error)

csvFile.close()
print(count)
