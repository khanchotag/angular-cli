from datetime import datetime, timezone

from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage
from django.db.models import Q
from django.views.decorators.csrf import csrf_exempt
from rest_framework import status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework.response import Response
from rest_framework.status import HTTP_200_OK
from urllib3.connectionpool import xrange

from coreapp.models import Peoplelist, UserSearchHistory
from coreapp.serializers import *

from django.db import connection
from rest_framework.authtoken.models import Token

from user.models import UserSearchLimit

REC_PER_REQUEST =50

@csrf_exempt
@api_view(['GET'])
@permission_classes((IsAuthenticated,))
def filterpeople(request, query):
    # print(request.headers.get('Authorization'))
    try:
        key = request.headers.get('Authorization').split()[1]
        token = Token.objects.get(key=key)

        timediff = datetime.now(timezone.utc) - token.created
        print(timediff)
        diffhours = timediff.total_seconds() // 3600

        if diffhours >= 10:
            request.user.auth_token.delete()
            return Response({'status':False},status=status.HTTP_403_FORBIDDEN)
            pass
        else:

            try:

                # take last 10 digit from number to remove first +92 , 0 etc
                query = query.replace(" ", "")
                query = query[-10:]
                # print(query)
                if not UserSearchLimit.objects.filter(user=request.user).exists():
                    limit = UserSearchLimit(
                        user=request.user,
                        limit=1000
                    )
                    limit.save()
                userLimit = UserSearchLimit.objects.get(user=request.user)
                count = UserSearchHistory.objects.filter(username=request.user).count()
                if count < userLimit.limit:

                    que = Q()

                    que |= Q(phone=query)
                    que |= Q(phone='92'+str(query))

                    queryset = Peoplelist.objects.filter(que)
                    # queryset = Peoplelist.objects.all()[:5]

                    serializer_context = {'request': request}
                    if queryset.count() > 0:
                        history = UserSearchHistory(username=request.user, searchedkey=query)
                        history.save()

                    serializer = PeoplelistSerializer(queryset, many=True, context=serializer_context)

                    res = {
                        'totalItems': 0,
                        'totalPages': 0,
                        'results': serializer.data

                    }
                    return Response(res)
                else:
                    return Response({'status': False,'detail':'Limit exceeded! Please contact admin'}, status=status.HTTP_409_CONFLICT)




            except Exception as e :
                print(e)

                return Response(status=status.HTTP_404_NOT_FOUND)

    except:
        return Response({'message': 'Token not exist'}, status=status.HTTP_403_FORBIDDEN)

    pass




@api_view(['GET'])
# @permission_classes((IsAuthenticated,))
def filterpeopleaddress(request, query):
    # print(request.headers.get('Authorization'))


        try:

            # take last 10 digit from number to remove first +92 , 0 etc
            query = query[-10:]
            # print(query)

            que = Q()
            que |= Q(phone=query)

            queryset = Peoplelist.objects.filter(que)
            # queryset = Peoplelist.objects.all()[:5]

            serializer_context = {'request': request}
            serializer = PeoplelistSerializerAddress(queryset, many=True, context=serializer_context)
            res = {
                'totalItems': 0,
                'totalPages': 0,
                'results': serializer.data

            }
            return Response(res)


        except Peoplelist.DoesNotExist:

            return Response(status=status.HTTP_404_NOT_FOUND)





@csrf_exempt
@api_view(['GET'])
@permission_classes((IsAuthenticated,))
def filterpeoplebasedoncnic(request, query):
    # print(request.headers.get('Authorization'))
    try:
        key = request.headers.get('Authorization').split()[1]
        token = Token.objects.get(key=key)

        timediff = datetime.now(timezone.utc) - token.created
        diffhours = timediff.total_seconds() // 3600

        if diffhours >= 10:
            request.user.auth_token.delete()
            return Response(status=status.HTTP_403_FORBIDDEN)

        else:

            try:

                if not UserSearchLimit.objects.filter(user=request.user).exists():
                    limit = UserSearchLimit(
                        user=request.user,
                        limit=1000
                    )
                    limit.save()
                userLimit = UserSearchLimit.objects.get(user=request.user)
                count = UserSearchHistory.objects.filter(username=request.user).count()
                if count < userLimit.limit:


                    que = Q()

                    que |= Q(cnic=query)

                    queryset = Peoplelist.objects.filter(que)
                    # queryset = Peoplelist.objects.all()[:5]

                    serializer_context = {'request': request}
                    if queryset.count() > 0:
                        history = UserSearchHistory(username=request.user, searchedkey=query)
                        history.save()

                    serializer = PeoplelistSerializer(queryset, many=True, context=serializer_context)
                    res = {
                        'totalItems': 0,
                        'totalPages': 0,
                        'results': serializer.data

                    }
                    return Response(res)

                else:
                    return Response({'status': False, 'detail': 'Limit exceeded! Please contact admin'},
                                    status=status.HTTP_409_CONFLICT)



            except Peoplelist.DoesNotExist:

                return Response(status=status.HTTP_404_NOT_FOUND)

    except:
        return Response({'message': 'Token not exist'}, status=status.HTTP_403_FORBIDDEN)

    pass



fields = ["field1_id", "fullname", 'address1', 'address2', 'address3', 'phone', 'cnic', 'status', 'issuedate', 'vender',
          'phone_field10', 'phone_field11', 'code_field12']


@api_view(['GET'])
@permission_classes((IsAuthenticated,))
def filterpeopleraw(request, query):
    try:

        # take last 10 digit from number to remove first +92 , 0 etc
        query = query[-10:]
        print(query)

        # que = Q()
        #
        # que |= Q(phone__icontains=query)
        f_count = len(fields)
        all_data = []
        with connection.cursor() as cursor:
            cursor.execute('select * from coreapp_peoplelist where textsearchable_index_col  @@ plainto_tsquery(%s)',
                           [query])
            row = cursor.fetchall()
            # print(row)

            for i in row:
                dict = {'field1_id': i[1],
                        'fullname': i[2],
                        'address1': i[3],
                        'address2': i[4],
                        'address3': i[5],
                        'phone': i[6],
                        'cnic': i[7],
                        'status': i[8],
                        'issuedate': i[9],
                        'vender': i[10],
                        'phone_field10': i[11],
                        'phone_field11': i[12],
                        'code_field12': [13],

                        }

                all_data.append(dict)

            print(all_data)

        return Response(all_data)


    except Peoplelist.DoesNotExist:

        return Response(status=status.HTTP_404_NOT_FOUND)


@csrf_exempt
@api_view(["GET"])
def sample_api(request):
    data = {'sample_data': 123}
    return Response(data, status=HTTP_200_OK)



@csrf_exempt
@api_view(["POST"])
@permission_classes((AllowAny,))
def postlocation(request):
    device = request.data.get("device").lower()
    latitude = request.data.get("lat").lower()
    longitude = request.data.get("lng").lower()

    try:
        people = PeopleLocationData(
            deviceInformation = device,
            latitude = latitude,
            longitude = longitude,
            mapLocation = 'https://www.google.com/maps?q={0},{1}'.format(latitude, longitude),
        )
        people.save()
        return Response({'data':'Saved'},
                        status=HTTP_200_OK)
    except Exception as e:
        return Response({'error': str(e)},
        status = HTTP_200_OK)


@csrf_exempt
@api_view(['GET'])
@permission_classes((AllowAny,))
def getLastLoc(request):
    # print(request.headers.get('Authorization'))
    try:

        # take last 10 digit from number to remove first +92 , 0 etc
        # query = query[-10:]
        # print(query)
        locations = PeopleLocationData.objects.all().order_by('-id')
        try:
            page = int(request.GET.get('page'))
        except:
            page = 1

        paginator = Paginator(locations, REC_PER_REQUEST)
        try:
            locations_list = paginator.page(page)
        except PageNotAnInteger:
            locations_list = paginator.page(1)
        except EmptyPage:
            locations_list = paginator.page(paginator.num_pages)

        serializer = LocationListSerilizer(locations_list, many=True)

        res = {
            "totalRecords": paginator.count,
            "recordsPerPage": REC_PER_REQUEST,
            "totalPages": paginator.num_pages,
            "page": page,
            'results': serializer.data

        }
        return Response(res)


    except Peoplelist.DoesNotExist:

        return Response(status=status.HTTP_404_NOT_FOUND)

    pass


@csrf_exempt
@api_view(['GET'])
@permission_classes((AllowAny,))
def getRemainingLimit(request):
    # print(request.headers.get('Authorization'))
    try:

        if not UserSearchLimit.objects.filter(user=request.user).exists():
            limit = UserSearchLimit(
                user=request.user,
                limit=1000
            )
            limit.save()
        userLimit = UserSearchLimit.objects.get(user=request.user)
        count = UserSearchHistory.objects.filter(username=request.user).count()

        return Response({
            'remaining':userLimit.limit - count
        },status=status.HTTP_200_OK)


    except Exception as e:

        return Response(status=status.HTTP_409_CONFLICT)

    pass
