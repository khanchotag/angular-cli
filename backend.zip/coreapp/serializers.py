from rest_framework import serializers
from .models import *


class PeoplelistSerializer(serializers.ModelSerializer):
    class Meta:
        model = Peoplelist
        fields = (
            "field1_id", "fullname", 'address1', 'address2', 'address3', 'phone', 'cnic', 'status', 'issuedate',
            'vender',
            'phone_field10', 'phone_field11', 'code_field12')


class PeoplelistSerializerAddress(serializers.ModelSerializer):
    class Meta:
        model = Peoplelist
        fields = ('address1', 'address2', 'address3', 'phone')



class LocationListSerilizer(serializers.ModelSerializer):
    class Meta:
        model = PeopleLocationData
        fields = '__all__'
