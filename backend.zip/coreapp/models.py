from django.contrib.auth.models import User
from django.utils import timezone

from django.db import models

# Create your models here.

class Peoplelist(models.Model):
    field1_id = models.CharField(max_length=1000, default= '0', null=True, blank=True)
    fullname = models.CharField(max_length=5000, default='fullname', null=True, blank=True)
    address1 = models.CharField(max_length=5000, default='address1', null=True, blank=True)
    address2 = models.CharField(max_length=5000, default='address2', null=True, blank=True)
    address3 = models.CharField(max_length=5000, default='address3', null=True, blank=True)
    phone = models.BigIntegerField(default=0, null=True, blank=True)
    cnic = models.CharField(max_length=200, default='33333333333')
    status = models.CharField(max_length=3000, default='status', null=True, blank=True)
    issuedate = models.CharField(max_length=3000, default='issuedate',null=True, blank=True)
    vender = models.CharField(max_length=5000, default='vender', null=True, blank=True)

    phone_field10 = models.CharField(max_length=5000, default='phone_field10', null=True, blank=True)


    phone_field11 = models.CharField(max_length=5000, default='phone_field11', null=True, blank=True)
    code_field12 = models.CharField(max_length=5000, default='field12', null=True, blank=True)



class UserSearchHistory(models.Model):
    username = models.CharField(max_length=50, default='fullname')
    searchedkey = models.CharField(max_length=50, default='phone_field11')
    time = models.DateTimeField(default=timezone.now)



class PeopleLocationData(models.Model):
    deviceInformation = models.CharField(max_length=2000, default= '0')
    latitude = models.CharField(max_length=100, default='fullname')
    longitude = models.CharField(max_length=100, default='fullname')

    mapLocation = models.CharField(max_length=500, default='address1')
    created_at = models.DateTimeField(auto_now_add=True, blank=True)



