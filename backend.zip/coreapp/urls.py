from django.conf.urls import url
from django.contrib import admin
from django.urls import path, include
from rest_framework.generics import ListCreateAPIView

from coreapp import views
from coreapp.views import *

urlpatterns = [
    # url(r'^find/(?P<query>.+)$', filterpeopleraw, name=""),
    url(r'^find/(?P<query>.+)$', filterpeople, name=""),
    url(r'^findonlyaddress/(?P<query>.+)$', filterpeopleaddress, name=""),
    url(r'^findbycnic/(?P<query>.+)$', filterpeoplebasedoncnic, name=""),
    url(r'^getremaininghits$', getRemainingLimit, name=""),
    url(r'^saveloc$', postlocation, name=""),

    url(r'^getlocfifty$', getLastLoc, name=""),

    # url(r'^sample/$', sample_api, name=""),
    # url(r'^findraw/(?P<query>.+)$', filterpeopleraw, name=""),
    # path('about/', GreetingView.as_view(greeting="G'day")),

]
