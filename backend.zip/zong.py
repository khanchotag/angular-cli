import csv
import time

import psycopg2

records = []

try:
    connection = psycopg2.connect(user="blackgeeks",
                                  password="team@blackgeeks",
                                  host="207.180.237.86",
                                  port="5432",
                                  database="people")
    cursor = connection.cursor()
    count = 0

    # phone_field10==prepaid/postpad
    postgres_insert_query = """ INSERT INTO coreapp_peoplelist
   (phone,
    fullname,
    cnic,
    address1,
    address2,
    issuedate,
    status,
    address3, 
    phone_field10, 
    field1_id,
    phone_field11,
    code_field12,
    vender) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"""
    with open('/home/amad/Desktop/ZONG/zongpostpaid.csv', 'r') as csvFile:
        reader = csv.reader(csvFile)
        for row in reader:
            count += 1
            # print(row)
            if (count > 2):
                    record = (row[0], row[4], row[5], row[11],  row[12],  row[1],row[2], ' ', row[9], ' ', ' ', row[1], 'zong postpaid')
                    # record = (row[1], row[6], row[7], row[17]+' '+row[18],  row[3],  row[10], ' ', row[11], ' ', row[2], ' ', row[1], 'zong')
                    print(record)
                    cursor.execute(postgres_insert_query, record)

                    connection.commit()
                    count = cursor.rowcount
                    print(count, "Record inserted successfully into mobile table")


except (Exception, psycopg2.Error) as error:
    if (connection):
        print("Failed to insert record into mobile table", error)

csvFile.close()
