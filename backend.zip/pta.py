import csv
import time

import psycopg2
csv.field_size_limit(100000000)

count = 0
records = []

try:
    connection = psycopg2.connect(user="blackgeeks",
                                  password="team@blackgeeks",
                                  host="207.180.237.86",
                                  port="5432",
                                  database="people")
    cursor = connection.cursor()
    postgres_insert_query = """ INSERT INTO coreapp_peoplelist 
    (
    fullname,
    address1,
    phone,
    cnic,
    status,
    vender) VALUES (%s,%s,%s,%s,%s,%s)"""

    with open('/home/data/PTA_data_06JAN19.txt', 'r',encoding="utf8", errors='ignore') as csvFile:
        reader = csv.reader(csvFile, delimiter='|')
        line_count = 0
        for row in reader:
            try:
                line_count += 1
                record = (row[1][:500], row[4][:4500], int(row[0]), row[2][:500], row[3][:500],'PTA (new data)')
#                print(record)
                records.append(record)
                if len(records)>=10000:
                    cursor.executemany(postgres_insert_query, records)
                    connection.commit()
                    count = cursor.rowcount
                    print(line_count, "Record inserted successfully into mobile table")
                    records = []
            except Exception as e:
                print('Exception', str(e))
        cursor.executemany(postgres_insert_query, records)
        connection.commit()
        count = cursor.rowcount
        print(line_count, "Record inserted successfully into mobile table")

except (Exception, psycopg2.Error) as error:
    print("Failed to insert record into mobile table", error)

csvFile.close()
print(count)
