import csv

import psycopg2
csv.field_size_limit(1000000050)
count = 0
records = []

try:
    connection = psycopg2.connect(user="blackgeeks",
                                  password="team@blackgeeks",
                                  host="207.180.237.86",
                                  port="5432",
                                  database="people")
    cursor = connection.cursor()
    postgres_insert_query = """ INSERT INTO coreapp_peoplelist 
     (
    fullname,
    phone,
    cnic,
    status,
    vender) VALUES (%s,%s,%s,%s,%s)"""

    with open('/home/data/data_subscriber_new_PRE_2019-03-05.csv', 'r',encoding="utf8", errors='ignore') as csvFile:

        reader = csv.reader(csvFile, delimiter='|')
        line_count = 0
        for row in reader:
            try:
                line_count += 1
                try:
                        record = (row[2][:500], int(row[1][:500]),row[3][:500],row[6][:500], 'PTA Zong(new data)')
                except:
                    record = ("no record", int(00),"no record","no record", 'PTA Zong(new data)')

	         # print(record)
                records.append(record)
                if len(records)>=10000:

                    cursor.executemany(postgres_insert_query, records)
                    connection.commit()
                    count = cursor.rowcount
                    print(line_count, "Record inserted successfully into mobile table")
                    records = []
            except Exception as e:
                print('Exception', str(e))

        cursor.executemany(postgres_insert_query, records)
        connection.commit()
        count = cursor.rowcount
        print(line_count, "Record inserted successfully into mobile table")

except (Exception, psycopg2.Error) as error:
    print("Failed to insert record into mobile table", error)

csvFile.close()
print(count)
