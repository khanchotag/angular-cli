import csv
import time

import psycopg2

records = []

try:
    connection = psycopg2.connect(user="blackgeeks",
                                  password="team@blackgeeks",
                                  host="207.180.237.86",
                                  port="5432",
                                  database="people")
    cursor = connection.cursor()
    count = 0

    # phone_field10==prepaid/postpad
    postgres_insert_query = """ INSERT INTO coreapp_peoplelist
   (phone,
    fullname,
    cnic,
    address1,
    issuedate,
    address2,
    phone_field10, 
    field1_id,
    phone_field11,
    status,
    code_field12,
    address3, 
    vender) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"""
    with open('/home/amad/warid1.csv', 'r') as csvFile:
        reader = csv.reader(csvFile)
        for row in reader:
            count += 1
            print(row)
            if (count != 1):
                try:

                    record = (row[0], row[1], row[2], row[3], ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', 'vfone')
                    cursor.execute(postgres_insert_query, record)
                    connection.commit()
                    count = cursor.rowcount
                    print(count, "Record inserted successfully into mobile table")
                except:
                    continue


except (Exception, psycopg2.Error) as error:
    if (connection):
        print("Failed to insert record into mobile table", error)

csvFile.close()
