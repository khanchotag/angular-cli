import csv
import time

import psycopg2
count=0;
records=[]


try:
   connection = psycopg2.connect(user="blackgeeks",
                                  password="team@blackgeeks",
                                  host="207.180.237.86",
                                  port="5432",
                                  database="people")
   cursor = connection.cursor()

   postgres_insert_query = """ INSERT INTO coreapp_peoplelist 
   (fullname,
   address1,
   address2,
   address3,
   phone,
   cnic,
   status,
   field1_id,
   phone_field10, 
   phone_field11,
   issuedate, 
   code_field12,
   vender) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"""
   with open('/home/amad/Desktop/MOBILINK/Mobilink-6.csv', 'r') as csvFile:
       reader = csv.reader(csvFile)

       for row in reader:
           count += 1
           if(count!=1):
                   if len(row[7])>19:

                       row[7]=''

                   if len(row[8])>28:

                       row[8]=''

                   record = (row[1], row[2], row[3], row[4], int(row[6]) , row[7], row[8], row[10], ' ', row[11], row[11], ' ', 'mobilink-6')
                   print(record)
                   cursor.execute(postgres_insert_query, record)
                   connection.commit()
                   count = cursor.rowcount
                   print(count, "Record inserted successfully into mobile table")
except (Exception, psycopg2.Error) as error :
    if(connection):
        print("Failed to insert record into mobile table", error)


csvFile.close()
print(count)