# or address1 ~* 'thokar' or address2 ~* 'thokar' or address3 ~* 'thokar'
# or address1 ~* 'valencia' or address2 ~* 'valencia' or address3 ~* 'valencia'
# or address1 ~* 'mohlanwal' or address2 ~* 'mohlanwal' or address3 ~* 'mohlanwal'
# or address1 ~* 'lake city' or address2 ~* 'lake city' or address3 ~* 'lake city'
# or address1 ~* 'eme' or address2 ~* 'eme' or address3 ~* 'eme'
# or address1 ~* 'chung' or address2 ~* 'chung' or address3 ~* 'chung'
# or address1 ~* 'rose garden' or address2 ~* 'rose garden' or address3 ~* 'rose garden'
# or address1 ~* 'maraka' or address2 ~* 'maraka' or address3 ~* 'maraka'

import csv
import time

import psycopg2

count = 0;
records = []

# try:
connection = psycopg2.connect(user="blackgeeks",
                              password="team@blackgeeks",
                              host="207.180.237.86",
                              port="5432",
                              database="people")
cursor = connection.cursor()

select_query = """ select phone from coreapp_peoplelist where address1 ~* 'bahria' or address2  ~* 'bahria' or address3  ~* 'bahria'
or address1 ~* 'thokar' or address2 ~* 'thokar' or address3 ~* 'thokar'
or address1 ~* 'valencia' or address2 ~* 'valencia' or address3 ~* 'valencia'
or address1 ~* 'mohlanwal' or address2 ~* 'mohlanwal' or address3 ~* 'mohlanwal'
or address1 ~* 'lake city' or address2 ~* 'lake city' or address3 ~* 'lake city'
or address1 ~* 'eme' or address2 ~* 'eme' or address3 ~* 'eme'
or address1 ~* 'chung' or address2 ~* 'chung' or address3 ~* 'chung'
or address1 ~* 'rose garden' or address2 ~* 'rose garden' or address3 ~* 'rose garden'
or address1 ~* 'maraka' or address2 ~* 'maraka' or address3 ~* 'maraka'
"""
cursor.execute(select_query)
records = cursor.fetchall()
file = open("lhr_bahria_side.txt", "w")

print(records)
for phone in records:
    print(phone[0])
    file.write('0'+str(phone[0])+'\n')

file.close()
# connection.commit()
# count = cursor.rowcount
# print(count, "Record inserted successfully into mobile table")
# except (Exception, psycopg2.Error) as error:
#     if (connection):
#         print("Failed to insert record into mobile table", error)
#
# print(count)
