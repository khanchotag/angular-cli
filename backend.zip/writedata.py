import csv
import psycopg2

connection = psycopg2.connect(user="blackgeeks",
                              password="team@blackgeeks",
                              host="207.180.237.86",
                              port="5432",
                              database="people")
cursor = connection.cursor()

print('calling query....')
# phone_Query = "select phone,id from coreapp_peoplelist  limit 25000 offset 100000"
phone_Query = "select phone,id from coreapp_peoplelist where (address1 ilike '%pattoki%' or address2 ilike '%pattoki%' or address3 ilike '%pattoki%')"
cursor.execute(phone_Query)
number_records = cursor.fetchall()

with open('peoplePattokiAll.csv', 'w') as writeFile:
    writer = csv.writer(writeFile)
    print('inserting....')
    for row in number_records:
        # print(row[0])

        writer.writerows([['0'+str(row[0])]])

writeFile.close()

# for row in number_records:
#     print(row[0])
