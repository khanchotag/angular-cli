from django.urls import path, re_path
from . import views
urlpatterns = [
    # url(r'^find/(?P<query>.+)$', filterpeopleraw, name=""),
    path('login/', views.login),
    path('signup/', views.signup),
    path('resetpermissions/', views.resetPermissions),
    path('listusers/', views.listUsers),
    # re_path('resetuserpermissions/(?P<user>+)$', views.reset_permission_by_user, name='reset user '),
    re_path('resetuserpermissions/(?P<user>.+)$', views.reset_permission_by_user, name='reset user '),
    re_path('resetLimit/(?P<user>.+)$', views.reset_Limit_by_user, name='reset user '),
    re_path('deleteuser/(?P<query>.+)$', views.deleteuser, name='del user')

]