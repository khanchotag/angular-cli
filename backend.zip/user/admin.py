from django.contrib import admin

# Register your models here.
from user.models import UserSearchLimit, UniqueUser

admin.site.register(UserSearchLimit)
admin.site.register(UniqueUser)