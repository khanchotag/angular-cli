
from django.contrib.auth.models import User
from django.db import models
from django.utils import timezone
# Create your models here.



class UniqueUser(models.Model):
    user= models.OneToOneField(User,on_delete=models.CASCADE)
    isSend= models.BooleanField(default=False)
    key = models.CharField(blank=True, max_length=250, default='NO_KEY')
    created_time = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return str(self.user.username)



class UserSearchLimit(models.Model):
    user= models.OneToOneField(User,on_delete=models.CASCADE)
    limit = models.IntegerField(blank=True,  default=500)
    created_at = models.DateTimeField(auto_now_add=True, blank=True)




    def __str__(self):
        return str(self.user.username)


