import random
import string
from django.contrib.auth.models import User

from django.contrib.auth import authenticate, logout
from django.shortcuts import render

# Create your views here.
from django.views.decorators.csrf import csrf_exempt
from rest_framework import generics
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from rest_framework.status import HTTP_400_BAD_REQUEST, HTTP_404_NOT_FOUND, HTTP_200_OK

from rest_framework.authtoken.models import Token

from .models import UniqueUser, UserSearchLimit
from . import models
from .serializers import *


@csrf_exempt
@api_view(["DELETE"])
@permission_classes((AllowAny,))
def resetPermissions(request):
    try:
        UniqueUser.objects.all().delete()
        return Response({'status': True})
    except:
        return Response({'status': False})

    pass


@csrf_exempt
@api_view(["GET"])
@permission_classes((AllowAny,))
def listUsers(request):
    try:
        serializer_context = {'request': request}
        queryset = User.objects.all()
        serializer = UserSerializer(queryset, many=True, context=serializer_context)

        return Response({'status': True,
                         'users': serializer.data})
    except:
        return Response({'status': False})

    pass


@csrf_exempt
@api_view(["GET"])
@permission_classes((AllowAny,))
def reset_permission_by_user(request, user):
    # try:
        # serializer_context = {'request': request}
        try:
            delUser=UniqueUser.objects.get(user__id = user)
            if(delUser):

                delUser.delete()
                return Response({'status': True})

            else:
                return Response({'status': False})


        except:
            return Response({'status': True})

            pass

    # except:
    #     return Response({'status': False})

        pass

@csrf_exempt
@api_view(["GET"])
@permission_classes((AllowAny,))
def reset_Limit_by_user(request, user):
    # try:
        # serializer_context = {'request': request}
        try:
            delUser=UniqueUser.objects.get(user__id = user)
            if(delUser):
                limit = UserSearchLimit.objects.get(user__id=user)
                limit.limit = limit.limit + limit.limit
                limit.save()
                delUser.delete()
                return Response({'status': True})

            else:
                return Response({'status': False})


        except:
            return Response({'status': True})

            pass

    # except:
    #     return Response({'status': False})

        pass


@csrf_exempt
@api_view(["GET"])
@permission_classes((AllowAny,))
def deleteuser(request, query):
    # try:
    user = User.objects.get(id=query)
    user.is_active = False;
    user.save()
    user.delete()

    return Response({'status': True})
    # except:
    #     return Response({'status': False})

    pass


@csrf_exempt
@api_view(["POST"])
@permission_classes((AllowAny,))
def signup(request):

    username = request.data.get("username").lower()

    password = request.data.get("password")

    if username is None or password is None:
        return Response({'error': 'Please provide both username and password'},
                        status=HTTP_400_BAD_REQUEST)


    if User.objects.filter(username=username).exists():
        return Response({'error': 'Username already exists'},
                        status=HTTP_400_BAD_REQUEST)


    if User.objects.filter(email=request.data['email']).exists():
        return Response({'error': 'Email already exists'},
                        status=HTTP_400_BAD_REQUEST)


    user = User(
        username=username,
        email=request.data['email']
    )
    user.set_password(raw_password=password)
    user.is_active = True
    user.save()

    limit = UserSearchLimit(user=user,
                            limit = request.data['limit'])
    limit.save()
    return Response({'result': 'User created successfully',},
                    status=HTTP_200_OK)


@csrf_exempt
@api_view(["POST"])
@permission_classes((AllowAny,))
def login(request):
    role = ['user']

    username = request.data.get("username").lower()

    password = request.data.get("password")

    if username is None or password is None:
        return Response({'error': 'Please provide both username and password'},
                        status=HTTP_400_BAD_REQUEST)
    if request.user.is_authenticated:
        logout(request)

    user = authenticate(username=username, password=password)
    print(user.is_active)
    if not user:
        return Response({'error': 'Invalid Credentials'},
                        status=HTTP_404_NOT_FOUND)

    if user.is_active == False:
        return Response({'error': 'Invalid Credentials'},
                        status=HTTP_404_NOT_FOUND)

    token, _ = Token.objects.get_or_create(user=user)

    if username == 'amad' or username == 'rizwan' or username == 'aqil07' or username == 'rehan':
        role.append('admin')
    isFirstTime = True
    try:
        print('Try')
        unique = UniqueUser.objects.get(user__username=username)
        print(unique.key)
        uniquecode = unique.key
        isFirstTime = False

    except:
        print('Except')
        uniquecode = randomCodeperUser()
        user_ = User.objects.get(username=username)
        unique = UniqueUser(user=user_, key=uniquecode, isSend=True)
        unique.save()
        isFirstTime = True

    return Response({'key': token.key,
                     'isUser': isFirstTime,
                     'role': role,
                     'identifier': uniquecode},
                    status=HTTP_200_OK)


def randomCodeperUser(stringLength=50):
    """Generate a random string of fixed length """
    letters = string.ascii_letters
    return ''.join(random.choice(letters) for i in range(stringLength))
