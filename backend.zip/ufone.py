import csv
import time

import psycopg2
records=[]

try:
   connection = psycopg2.connect(user="blackgeeks",
                                  password="team@blackgeeks",
                                  host="207.180.237.86",
                                  port="5432",
                                  database="people")
   cursor = connection.cursor()
   count = 0

   # phone_field10==prepaid/postpad
   postgres_insert_query = """ INSERT INTO coreapp_peoplelist
   (phone,
    fullname,
    address1,
    address2,
    cnic,
    phone_field10, 
    field1_id,
    issuedate,
    phone_field11,
    status,
    code_field12,
    address3, 
    vender) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"""
   with open('/home/amad/ufone1.csv', 'r') as csvFile:
       reader = csv.reader(csvFile)
       for row in reader:
           count += 1
           # print(row)
           if(count>=3):
               try:
                   if len(row[8]) > 19:
                       row[8] = ''

                   if len(row[9]) > 28:
                       row[9] = ''
                   record=  (int(row[0]),row[4],row[6],row[7],row[8],row[10],row[13],row[3],row[12],row[9],row[2],row[1],'ufone-1')

                   cursor.execute(postgres_insert_query, record)
                   connection.commit()
                   count = cursor.rowcount
                   print(count, "Record inserted successfully into mobile table")
               except:
                   print('Error')
                   continue


except (Exception, psycopg2.Error) as error :
    if(connection):
        print("Failed to insert record into mobile table", error)


csvFile.close()
#
# import csv
#
# with open('/home/amad/Desktop/Ufone/Ufone/Ufone-1.csv', 'r') as csvFile:
#     reader = csv.reader(csvFile)
#     print(reader.length)
#
#     # for row in reader:
#     #     # next(row)
#     #     print(row)
