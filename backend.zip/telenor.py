import csv
import time

import psycopg2

records = []

try:
    connection = psycopg2.connect(user="blackgeeks",
                                  password="team@blackgeeks",
                                  host="207.180.237.86",
                                  port="5432",
                                  database="people")
    cursor = connection.cursor()
    count = 0

    # phone_field10==prepaid/postpad
    postgres_insert_query = """ INSERT INTO coreapp_peoplelist
   (phone,
    fullname,
    cnic,
    address1,
    address2,
    phone_field10, 
    field1_id,
    issuedate,
    phone_field11,
    status,
    code_field12,
    address3, 
    vender) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"""
    with open('/home/amad/Desktop/Ufone/Ufone/Ufone-2.csv', 'r') as csvFile:
        reader = csv.reader(csvFile)
        for row in reader:
            count += 1
            # print(row)
            if (count != 1):
                record = (row[0], row[1] + row[2], row[3], row[4], ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', 'telenor')
                try:
                    cursor.execute(postgres_insert_query, record)
                    connection.commit()
                    count = cursor.rowcount
                    print(count, "Record inserted successfully into mobile table")
                except:
                    continue


except (Exception, psycopg2.Error) as error:
    if (connection):
        print("Failed to insert record into mobile table", error)

csvFile.close()
